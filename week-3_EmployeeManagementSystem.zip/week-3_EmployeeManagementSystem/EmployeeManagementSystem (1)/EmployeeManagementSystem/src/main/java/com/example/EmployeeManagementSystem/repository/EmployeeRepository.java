package com.example.EmployeeManagementSystem.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.EmployeeManagementSystem.entities.Employee;
import com.example.EmployeeManagementSystem.projections.EmployeeProjection;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByName(String name);

    List<Employee> findByEmail(String email);

    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<Employee> findByDepartmentName(@Param("departmentName") String departmentName);

    @Query("SELECT e FROM Employee e WHERE e.name LIKE %:name%")
    List<Employee> findByNameContaining(@Param("name") String name);

    @Query("SELECT e FROM Employee e WHERE e.name LIKE %:name%")
    Page<Employee> findByNameContaining(@Param("name") String name, Pageable pageable);

    @Query("SELECT e.id AS id, e.name AS name, e.email AS email, e.department.name AS departmentName FROM Employee e")
    List<EmployeeProjection> findEmployeeProjections();
}
